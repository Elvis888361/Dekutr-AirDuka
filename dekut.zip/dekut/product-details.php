<?php 
  
  


  
if (isset($_GET['del'])) {
  $id = $_GET['del'];
  mysqli_query($db, "DELETE FROM products WHERE id=$id");
  $_SESSION['message'] = "user number deleted!"; 
  header('location: admins.php');
}




    include "db_conn.php";
if (isset($_POST['submit'])){
    $product_type=$_POST['product_type'];
    $phone=$_POST['phone'];
    $price=$_POST['price'];
    $product_detail=$_POST['product_detail'];

    $data = "product_type=".$product_type."&phone=".$phone;
    
    if (empty($product_type)) {
      echo "product_type is required";
      exit;
    }else if(empty($phone)){
      echo "phone is required";
      exit;
    }else if(empty($price)){
      echo "price is required";
      exit;
    }else {
      // hashing the priceword
        
      if (isset($_FILES['pp']['name'])AND !empty($_FILES['pp']['name'])) {
         

         $img_name=$_FILES['pp']['name'];
       
         $tmp_name=$_FILES['pp']['tmp_name'];
         $error=$_FILES['pp']['error'];
         
         if ($error===0) {
            $img_ex=pathinfo($img_name,PATHINFO_EXTENSION);
           
            $img_ex_to_lc=strtolower($img_ex);
            $allowed_exs=array('jpg','jpeg','png');
            if (in_array($img_ex_to_lc, $allowed_exs)) {
               $new_img_name=uniqid($phone,true).'.'.$img_ex_to_lc;
               $img_upload_path='uploads/'.$new_img_name;
               move_uploaded_file($tmp_name, $img_upload_path);
               //insert to database
                  $sql = "INSERT INTO products(product_type, phone, price,product_detail,pp) 
                 VALUES(?,?,?,?,?)";
               $stmt = $conn->prepare($sql);
               $stmt->execute([$product_type,$phone,$price,$product_detail,$new_img_name ]);
                header("Location: receipt.html");
                exit();
            }else{
               $em = "you cant upload files of this type";
               header("Location: product-details.php");
               exit;
            }
         }else{
            echo "unknown error occured";
            exit;
         }
      }else{ 

       }
    }}




?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>product details</title>
  <meta content="" name="description">
  <meta content="" name="keywords">


  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">


  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

  
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

 
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

 
  <main id="main" class="main-page">

    
    <section id="speakers-details">
      <div class="container">
        <div class="section-header">
          <h2>Find Customers in your University</h2>
          <p>Receive enquiries directly to your WhatsApp</p>
        </div>
        
        <div class="row">
          <div class="col-md-6">

            <img src="assets/img/er.jpg" alt="Speaker 1" class="img-fluid">
            <img src="assets/img/er1.jpg" alt="Speaker 1" class="img-fluid">
          </div>

          <div class="col-md-6">
            <form method="POST" action="" enctype="multipart/form-data">
            <div class="details">
              <h2>Product Details</h2>
            </div>
            <?php if(isset($_GET['error'])){ ?>
              <div class="alert alert-danger" role="alert">
              <?php echo $_GET['error']; ?>
            </div>
              <?php } ?>

              <?php if(isset($_GET['success'])){ ?>
              <div class="alert alert-success" role="alert">
              <?php echo $_GET['success']; ?>
            </div>
              <?php } ?>
            <div><label>Product type</label><SELECT name="product_type"><option value="jewery&clothings">jewery&clothings</option><option value="electronics">electronics</option><option value="food">Food Stuff</option><option value="house">House Items</option></SELECT><br><br></div>
            <div><h4>please make sure to enter your phone number correctly beginning with 254</h4><i class="bi bi-telephone-inbound-fill"></i></i><input type="text" name="phone" placeholder="+254"><br><br></div>
            <div>
              <label>Product image</label></i><input name="pp" type="file"><br><br>
            </div>
            <div>
              <i class="bi bi-cash-stack"></i><input type="number" name="price"placeholder="Enter pricing"><br><br>
            </div>
            <div>
              <i class="bi bi-info-circle-fill"></i><textarea name="product_detail"placeholder="Enter small details about your product"></textarea><br><br>
            </div>
            <div>
              <button type="submit" name="submit" class="btn btn-primary">Submit</button>
            </div>
          </div>
        </form>
        </div>
      
      </div>

    </section>

  </main>
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-info">
            <img src="assets/img/logo.png" alt="TheEvenet">
            <p>AirDuka is an online marketplace that connects buyers and sellers. With AirDuka, you can reach more customers and expand your business.

AirDuka is the only online marketplace that has listed service providers in every industry. We guarantee you will find whatever you are looking for.</p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bi bi-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bi bi-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bi bi-chevron-right"></i> <a href="#">Services</a></li>
              <li><i class="bi bi-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bi bi-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
              Bomas Street <br>
              Nyeri, Kimathi<br>
              Kenya <br>
              <strong>Phone:</strong> +254745638455<br>
              <strong>Email:</strong> elvisndegwa90gmail.com<br>
            </p>

            <div class="social-links">
              <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
              <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
              <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
              <a href="#" class="google-plus"><i class="bi bi-instagram"></i></a>
              <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
            </div>

          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong>TheEvent</strong>. All Rights Reserved
      </div>
      <div class="credits">
       
        Designed by <a href="https://elvisndegwa90gmail.com/">Elvis Ndegwa</a>
      </div>
    </div>
  </footer>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <script src="assets/js/main.js"></script>

</body>

</html>