<?php 

$sName = "localhost";
$uName = "id18772111_recon123";
$pass = "]uYdsqelFm)9lsc-";
$db_name = "id18772111_try";

try {
    $conn = new PDO("mysql:host=$sName;dbname=$db_name", 
                    $uName, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e){
  echo "Connection failed : ". $e->getMessage();
}