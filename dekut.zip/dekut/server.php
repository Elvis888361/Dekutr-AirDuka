
<?php 
	
	


  
if (isset($_GET['del'])) {
	$id = $_GET['del'];
	mysqli_query($db, "DELETE FROM products WHERE id=$id");
	$_SESSION['message'] = "user number deleted!"; 
	header('location: admins.php');
}




    include "db_conn.php";
if (isset($_POST['submit'])){
    $product_type=$_POST['product_type'];
    $phone=$_POST['phone'];
    $price=$_POST['price'];
    $product_detail=$_POST['product_detail'];

    $data = "product_type=".$product_type."&phone=".$phone;
    
    if (empty($product_type)) {
      echo "product_type is required";
      exit;
    }else if(empty($phone)){
      echo "phone is required";
      exit;
    }else if(empty($price)){
      echo "price is required";
      exit;
    }else {
      // hashing the priceword
        
      if (isset($_FILES['pp']['name'])AND !empty($_FILES['pp']['name'])) {
         

         $img_name=$_FILES['pp']['name'];
       
         $tmp_name=$_FILES['pp']['tmp_name'];
         $error=$_FILES['pp']['error'];
         
         if ($error===0) {
            $img_ex=pathinfo($img_name,PATHINFO_EXTENSION);
           
            $img_ex_to_lc=strtolower($img_ex);
            $allowed_exs=array('jpg','jpeg','png');
            if (in_array($img_ex_to_lc, $allowed_exs)) {
               $new_img_name=uniqid($phone,true).'.'.$img_ex_to_lc;
               $img_upload_path='uploads/'.$new_img_name;
               move_uploaded_file($tmp_name, $img_upload_path);
               //insert to database
                  $sql = "INSERT INTO products(product_type, phone, price,product_detail,pp) 
                 VALUES(?,?,?,?,?)";
               $stmt = $conn->prepare($sql);
               $stmt->execute([$product_type,$phone,$price,$product_detail,$new_img_name ]);
                header("Location: receipt.html");
                exit();
            }else{
               $em = "you cant upload files of this type";
               header("Location: product-details.php");
               exit;
            }
         }else{
            echo "unknown error occured";
            exit;
         }
      }else{ 

       }
    }}else{
    	 header("Location: index.php");
        exit;
    }




?>