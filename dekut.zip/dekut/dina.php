<?php 
  session_start();
  $db = mysqli_connect('localhost', 'id18772111_recon123', ']uYdsqelFm)9lsc-', 'id18772111_try');

  if (!$db) {

    
    $_SESSION['message'] = "connection failed"; 
    header('location: index.php');
    # code...
  }
  if (isset($_GET['del'])) {
	$id = $_GET['del'];
	mysqli_query($db, "DELETE FROM products WHERE id=$id");
	$_SESSION['message'] = "user number deleted!"; 
	header('location: dina.php');
}?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>admin</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <link rel="stylesheet" type="text/css" href="styles.css">

  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

  <header id="header" class="d-flex align-items-center header-inner">
    <div class="container-fluid container-xxl d-flex align-items-center">

      <div id="logo" class="me-auto">
        <a href="index.html" class="scrollto"><img src="assets/img/logo.png" alt="" title=""></a>
      </div>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto " href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">Help</a></li>
         
         
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
      

    </div>
  </header>

  <main id="main" class="main-page">

   	
	<?php 
		$results = mysqli_query($db, "SELECT * FROM products"); 
	?>

<table border="1">
	<thead>
		<tr>
			<th colspan="2">
				Phone Number
			</th>
			<th colspan="2">
				Product Type
			</th>
			<th colspan="2">
				Price
			</th>
			<th colspan="2">
				Product detail
			</th>
			<th colspan="2">
				image
			</th>
			<th colspan="2">
				Action
			</th>
		</tr>
	</thead>
	
	 <?php if($results->num_rows > 0){ ?>
	 	<?php while($row = $results->fetch_assoc()){ ?>
		<tr>
			<td colspan="2">
				<?php echo $row['phone']; ?>
			</td>
			<td colspan="2">
				<?php echo $row['product_type']; ?>
			</td>
			<td colspan="2">
				<?php echo $row['price']; ?>
			</td>
			<td colspan="2">
				<?php echo $row['product_detail']; ?>
			</td>
			<td colspan="2">
				<?php 
$imageURL = 'uploads/'.$row["pp"];
 ?>
                <img src="<?php echo $imageURL; ?>" width="400" 
     height="400"/>
			</td>
			
			<td colspan="2">
				<a href="?del=<?php echo $row['id']; ?>" class="del_btn">Delete</a>
			</td>
		</tr>
	<?php } ?>
	 
      
      <?php }else{ ?> 
      <p class="status error">Image(s) not found...</p> 
  <?php } ?>


</table>
  </main>
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-info">
            <img src="assets/img/logo.png" alt="TheEvenet">
            <p>AirDuka is an online marketplace that connects buyers and sellers. With AirDuka, you can reach more customers and expand your business.

AirDuka is the only online marketplace that has listed service providers in every industry. We guarantee you will find whatever you are looking for.</p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bi bi-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bi bi-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bi bi-chevron-right"></i> <a href="#">Services</a></li>
              <li><i class="bi bi-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bi bi-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
              Bomas Street <br>
              Nyeri, Kimathi<br>
              Kenya <br>
              <strong>Phone:</strong> +254745638455<br>
              <strong>Email:</strong> elvisndegwa90gmail.com<br>
            </p>

            <div class="social-links">
              <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
              <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
              <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
              <a href="#" class="google-plus"><i class="bi bi-instagram"></i></a>
              <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
            </div>

          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong>TheEvent</strong>. All Rights Reserved
      </div>
      <div class="credits">
       
        Designed by <a href="https://elvisndegwa90gmail.com/">Elvis Ndegwa</a>
      </div>
    </div>
  </footer>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <script src="assets/js/main.js"></script>

</body>

</html>